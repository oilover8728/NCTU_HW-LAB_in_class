#include "matrix33.h"

matrix33::matrix33(){
}

matrix33::matrix33(const vector3 &e,const vector3 &f,const vector3 &g){
	setm(e,f,g);
}
	
matrix33::matrix33(const matrix33 &v){
	setm(v.V[0], v.V[1], v.V[2]);
}


vector3 &matrix33::operator [] (unsigned int index){
	return V[index];
}

const vector3 &matrix33::operator [] (unsigned int index) const{
	return V[index];
}

matrix33 &matrix33::operator =  (const matrix33 &v){
	setm(v.V[0], v.V[1], v.V[2]);
}

matrix33 &matrix33::operator += (const matrix33 &v){
	setm(v.V[0]+V[0], v.V[1]+V[1], v.V[2]+V[2]);
}

matrix33 &matrix33::operator -= (const matrix33 &v){
	setm(v.V[0]-V[0], v.V[1]-V[1], v.V[2]-V[2]);
}

matrix33 &matrix33::operator *= (float f){
	setm(V[0]*f, V[1]*f, V[2]*f);
}

matrix33 &matrix33::operator /= (float f){
	setm(V[0]/f, V[1]/f, V[2]/f);
}

bool operator == (const matrix33 &a, const matrix33 &b){
	if(a.V[0]==b.V[0] && a.V[1]==b.V[1] && a.V[2]==b.V[2]){
		return true;
	}
	else{
		return false;
	}
}

bool operator != (const matrix33 &a, const matrix33 &b){
	if(a==b){
		return false;
	}
	else{
		return true;
	}
}

matrix33 operator - (const matrix33 &a){
	return matrix33(-a.V[0], -a.V[1], -a.V[2]);
}

matrix33 operator + (const matrix33 &a, const matrix33 &b){
	return matrix33(a.V[0]+b.V[0], a.V[1]+b.V[1], a.V[2]+b.V[2]);
}

matrix33 operator - (const matrix33 &a, const matrix33 &b){
	return matrix33(a.V[0]-b.V[0], a.V[1]-b.V[1], a.V[2]-b.V[2]);
}

matrix33 operator * (const matrix33 &v, float f){
	return matrix33(v.V[0]*f, v.V[1]*f, v.V[2]*f);
}

matrix33 operator * (const matrix33 &a, const matrix33 &b){
	return matrix33(vector3((a.V[0].x*b.V[0].x+a.V[1].x*b.V[0].y+a.V[2].x*b.V[0].z),
							(a.V[0].y*b.V[0].x+a.V[1].y*b.V[0].y+a.V[2].y*b.V[0].z),
							(a.V[0].z*b.V[0].x+a.V[1].z*b.V[0].y+a.V[2].z*b.V[0].z)),
					vector3((a.V[0].x*b.V[1].x+a.V[1].x*b.V[1].y+a.V[2].x*b.V[1].z),
							(a.V[0].y*b.V[1].x+a.V[1].y*b.V[1].y+a.V[2].y*b.V[1].z),
							(a.V[0].z*b.V[1].x+a.V[1].z*b.V[1].y+a.V[2].z*b.V[1].z)),
					vector3((a.V[0].x*b.V[2].x+a.V[1].x*b.V[2].y+a.V[2].x*b.V[2].z),
							(a.V[0].y*b.V[2].x+a.V[1].y*b.V[2].y+a.V[2].y*b.V[2].z),
							(a.V[0].z*b.V[2].x+a.V[1].z*b.V[2].y+a.V[2].z*b.V[2].z))
					);
}

matrix33 operator * (float f, const matrix33 &v){
	return matrix33(v.V[0]*f, v.V[1]*f, v.V[2]*f);
}

matrix33 operator / (const matrix33 &v, float f){
	return matrix33(v.V[0]/f, v.V[1]/f, v.V[2]/f);
}

void matrix33::setm(vector3 e, vector3 f, vector3 g){
	V[0] = e;
	V[1] = f;
	V[2] = g; 	
}

void matrix33::printMatrix() const{
	std::cout << V[0].x << " " << V[1].x << " " << V[2].x << std::endl;
	std::cout << V[0].y << " " << V[1].y << " " << V[2].y << std::endl;
	std::cout << V[0].z << " " << V[1].z << " " << V[2].z << std::endl;
}

float matrix33::determinant(){
	return V[0].x*V[1].y*V[2].z+V[0].y*V[1].z*V[2].x+V[0].z*V[1].x*V[2].y-V[0].z*V[1].y*V[2].x-V[0].y*V[1].x*V[2].z-V[0].x*V[1].z*V[2].y;
	
}
	 
matrix33 matrix33::invert(){
	vector3 h(V[1].y*V[2].z-V[2].y*V[1].z, V[2].y*V[0].z-V[0].y*V[2].z, V[0].y*V[1].z-V[1].y*V[0].z),
			i(V[2].x*V[1].z-V[1].x*V[2].z, V[0].x*V[2].z-V[2].x*V[0].z, V[1].x*V[0].z-V[0].x*V[1].z),
			j(V[1].x*V[2].y-V[2].x*V[1].y, V[2].x*V[0].y-V[0].x*V[2].y, V[0].x*V[1].y-V[1].x*V[0].y);
	float d=determinant();
	setm(h/d, i/d, j/d);
	return *this;
}

matrix33 matrix33::identity(){
	vector3 k(1, 0, 0),l(0, 1, 0),m(0, 0, 1);
	setm(k,l,m);
}


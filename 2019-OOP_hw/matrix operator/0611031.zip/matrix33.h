#ifndef _MATRIX33_H_
#define _MATRIX33_H_

#include "vector3.h"

class matrix33 
{
public:
	/* data members */
	vector3 V[3];

	//****************************************************//
	//  You need to implement the following functions !!  //
	//****************************************************//

public:
	/* constructors */
	// default constructor -- don't do anything with it
	matrix33();
	
	// constructor with initializing float values
	matrix33(const vector3 &e,const vector3 &f,const vector3 &g);
	
	// constructor with initializing vector3
	matrix33(const matrix33 &v);

public:
	/* Operators */
	
	// access element
	vector3                 &operator [] (unsigned int index);
	const vector3           &operator [] (unsigned int index) const;
	
	matrix33               &operator =  (const matrix33 &v);
	matrix33               &operator += (const matrix33 &v);
	matrix33               &operator -= (const matrix33 &v);
	matrix33               &operator *= (float f);
	matrix33               &operator /= (float f);
	friend bool           operator == (const matrix33 &a, const matrix33 &b);
	friend bool           operator != (const matrix33 &a, const matrix33 &b);
	friend matrix33        operator - (const matrix33 &a);
	friend matrix33        operator + (const matrix33 &a, const matrix33 &b);
	friend matrix33        operator - (const matrix33 &a, const matrix33 &b);
	friend matrix33        operator * (const matrix33 &v, float f);
	friend matrix33        operator * (const matrix33 &a, const matrix33 &b);
	friend matrix33        operator * (float f, const matrix33 &v);
	friend matrix33        operator / (const matrix33 &v, float f);

 public:
	 /* Methods */

	 // set values (e.g. x = xIn, ...)
	 void setm(vector3 e, vector3 f, vector3 g);

	  // print matrix using std::cout
	 void printMatrix() const;
	 
	 float determinant();
	 
	 matrix33 invert();
	 
	 matrix33 identity();
};

#endif

